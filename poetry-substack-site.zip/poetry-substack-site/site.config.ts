export const siteConfig = {
  title: "Modern Poetry",
  description: "A minimal, elegant poetry journal that pulls from Substack.",
  author: "Your Name",
  substackHandle: process.env.NEXT_PUBLIC_SUBSTACK_HANDLE || "your-substack",
  feedUrl:
    process.env.SUBSTACK_FEED_URL ||
    "https://status.substack.com/feed", // placeholder, set your own in .env.local
  revalidateSeconds: Number(process.env.REVALIDATE_SECONDS || 1800)
};
