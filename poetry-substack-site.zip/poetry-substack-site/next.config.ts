import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  experimental: {
    optimizePackageImports: ["date-fns"]
  },
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "**.substack.com" }
    ]
  }
};

export default nextConfig;
