import Parser from "rss-parser";
import sanitizeHtml from "sanitize-html";
import { format } from "date-fns";
import { siteConfig } from "@/site.config";

export type Post = {
  id: string;
  title: string;
  link: string;
  date: string;
  isoDate?: string;
  categories?: string[];
  excerpt?: string;
  image?: string | null;
};

const parser = new Parser({
  customFields: {
    item: [
      ["content:encoded", "contentEncoded"],
      ["media:content", "mediaContent", { keepArray: true }],
      ["dc:creator", "creator"]
    ]
  }
});

export async function getPosts(limit = 20): Promise<Post[]> {
  const url = siteConfig.feedUrl;
  if (!url) throw new Error("Missing SUBSTACK_FEED_URL");

  const feed = await parser.parseURL(url);

  const posts: Post[] = (feed.items || []).map((item, idx) => {
    const html = (item as any).contentEncoded || item["content"] || "";
    const excerpt = sanitizeHtml(html, { allowedTags: [], allowedAttributes: {} })
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 300);

    // Try to find an image:
    let image: string | null = null;
    const match = html.match(/<img[^>]+src=["']([^"']+)["']/i);
    if (match) image = match[1];

    const d = item.isoDate ? new Date(item.isoDate) : item.pubDate ? new Date(item.pubDate as string) : null;
    const date = d ? format(d, "PPP") : "";

    return {
      id: item.guid || item.link || String(idx),
      title: item.title || "(untitled)",
      link: item.link || "#",
      date,
      isoDate: item.isoDate,
      categories: item.categories as string[] | undefined,
      excerpt,
      image
    };
  });

  // Sort by isoDate desc if present
  posts.sort((a, b) => (b.isoDate || "").localeCompare(a.isoDate || ""));
  return posts.slice(0, limit);
}
