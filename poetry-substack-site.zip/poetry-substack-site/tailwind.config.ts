import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ["var(--font-inter)"],
        serif: ["var(--font-literata)"]
      }
    }
  },
  plugins: [require("@tailwindcss/typography")]
};
export default config;
