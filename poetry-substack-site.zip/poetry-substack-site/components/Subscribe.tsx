"use client";

import { useEffect } from "react";
import { siteConfig } from "@/site.config";

export default function Subscribe() {
  useEffect(() => {
    // Load Substack's embed script
    const script = document.createElement("script");
    script.src = "https://substack.com/embed.js";
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const handle = process.env.NEXT_PUBLIC_SUBSTACK_HANDLE || "your-substack";
  const url = `https://${handle}.substack.com`;

  return (
    <section id="subscribe" className="mx-auto max-w-2xl">
      <div className="rounded-2xl border border-white/10 bg-[var(--card)] p-6">
        <h3 className="text-lg font-semibold">Get new poems by email</h3>
        <p className="text-sm text-[var(--muted)] mb-4">
          Subscribe to be notified when a new piece drops.
        </p>
        <div
          className="substack-embed"
          data-embed-for={url}
          data-mode="inline"
        ></div>
        <p className="mt-3 text-xs text-[var(--muted)]">
          Powered by Substack — we never share your email.
        </p>
      </div>
    </section>
  );
}
