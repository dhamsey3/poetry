"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

export default function Header() {
  const [dark, setDark] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("theme");
    if (stored) setDark(stored === "dark");
    document.documentElement.classList.toggle("dark", dark);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("theme", dark ? "dark" : "light");
  }, [dark]);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[var(--bg)]/70 backdrop-blur">
      <div className="mx-auto max-w-4xl px-4 py-4 flex items-center justify-between">
        <Link href="/" className="font-semibold tracking-tight text-xl">
          Modern Poetry
        </Link>
        <nav className="flex items-center gap-4">
          <a href="#subscribe" className="text-sm text-[var(--muted)] hover:text-white">Subscribe</a>
          <button
            onClick={() => setDark((d) => !d)}
            className="rounded border border-white/10 px-3 py-1 text-sm hover:bg-white/5"
            aria-label="Toggle theme"
          >
            {dark ? "☾" : "☀"}
          </button>
        </nav>
      </div>
    </header>
  );
}
