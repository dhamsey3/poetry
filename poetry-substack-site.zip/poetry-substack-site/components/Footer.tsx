import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-white/10 mt-16">
      <div className="mx-auto max-w-4xl px-4 py-10 text-sm text-[var(--muted)]">
        <p>
          © {new Date().getFullYear()} Modern Poetry • Powered by Substack RSS • Built with Next.js & Tailwind
        </p>
        <p className="mt-2">
          <Link href="https://substack.com" className="hover:underline">Substack</Link> •{" "}
          <Link href="https://nextjs.org" className="hover:underline">Next.js</Link>
        </p>
      </div>
    </footer>
  );
}
