import Link from "next/link";
import type { Post } from "@/lib/getPosts";

export default function PostCard({ post }: { post: Post }) {
  return (
    <article className="rounded-2xl border border-white/10 bg-[var(--card)] overflow-hidden">
      {post.image && (
        <div className="aspect-[16/9] overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={post.image} alt="" className="h-full w-full object-cover" />
        </div>
      )}
      <div className="p-5">
        <time className="text-xs text-[var(--muted)]">{post.date}</time>
        <h2 className="mt-2 text-xl font-semibold tracking-tight">
          <Link href={post.link} target="_blank" className="hover:underline">
            {post.title}
          </Link>
        </h2>
        {post.excerpt && (
          <p className="mt-3 text-sm text-white/80">{post.excerpt}…</p>
        )}
        <div className="mt-4">
          <Link
            href={post.link}
            target="_blank"
            className="inline-flex items-center gap-2 text-sm rounded px-3 py-1 border border-white/10 hover:bg-white/5"
          >
            Read on Substack ↗
          </Link>
        </div>
      </div>
    </article>
  );
}
