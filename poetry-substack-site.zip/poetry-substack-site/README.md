# Modern Poetry — Substack-fed Next.js Site

A sleek, minimal poetry site that **pulls your posts from Substack via RSS** and displays them beautifully. Includes a Substack email signup embed, dark mode, and fast SSR/ISR with Next.js 14.

https://github.com (optional repo if you publish this)

## Features

- ⚡️ Next.js 14 (App Router) + TypeScript
- 🎨 Tailwind CSS + Typography for clean, readable poems
- 🌓 Dark mode with local preference
- 🔁 Incremental revalidation (default: every 30 minutes)
- ✉️ Substack embed (inline subscribe form)
- 🧼 Safe excerpts via `sanitize-html`
- 🖼 Auto-pulls first image from each post (if present)
- 🔗 “Read on Substack” links (keeps canonical SEO with Substack)

## 1) Configure

Create `.env.local` at the project root:

```env
# Your Substack RSS feed:
SUBSTACK_FEED_URL="https://YOUR-HANDLE.substack.com/feed"

# Used by the Subscribe embed and any client-side references:
NEXT_PUBLIC_SUBSTACK_HANDLE="YOUR-HANDLE"

# Optional: revalidation interval in seconds (default 1800 = 30 min)
REVALIDATE_SECONDS=1800
```

Tip: You can also point to category/tag feeds, e.g. `https://YOUR-HANDLE.substack.com/feed/tag/poetry`

## 2) Install & Run

```bash
pnpm i   # or: npm i  |  yarn
pnpm dev # or: npm run dev
```

Open http://localhost:3000

## 3) Deploy

- **Vercel** (recommended): Import the repo, set the same env vars in Project Settings → Environment Variables, and deploy.
- **Docker** (optional): You can containerize with a simple Dockerfile (FROM node:20-alpine) and run `next start`.

## Notes

- Substack’s public API is limited; this starter uses RSS. Some publications include full HTML in `content:encoded`, others include excerpts only. We display a clean excerpt and link to Substack for the canonical post.
- If your publication requires paid access, only free/preview content will appear via RSS.
- Design tweaks live in `app/globals.css`, `components/*`, and `tailwind.config.ts`. The poem class (`.poem`) preserves line breaks/indentation.
- If you later want local post pages, you can add a route that fetches and sanitizes full HTML by proxying the RSS `content:encoded`. Keep an eye on robots/ToS for scraping.

## License

MIT — Enjoy and make it yours.
