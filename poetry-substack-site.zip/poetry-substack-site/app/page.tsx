import { getPosts } from "@/lib/getPosts";
import PostCard from "@/components/PostCard";
import Subscribe from "@/components/Subscribe";
import { siteConfig } from "@/site.config";

export const revalidate = siteConfig.revalidateSeconds;

export default async function Home() {
  const posts = await getPosts(24);

  return (
    <div className="space-y-12">
      <section className="text-center">
        <h1 className="text-4xl md:text-5xl font-semibold tracking-tight">
          Modern Poetry
        </h1>
        <p className="mt-3 text-[var(--muted)]">
          Poems, meditations, and fragments — served fresh from Substack.
        </p>
      </section>

      <section className="grid gap-6 sm:grid-cols-2">
        {posts.map((p) => (
          <PostCard key={p.id} post={p} />
        ))}
      </section>

      <Subscribe />
    </div>
  );
}
